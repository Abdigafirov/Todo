import {createAction} from "@reduxjs/toolkit";

export const apiCall = createAction('api/apiCall')