import axios from "axios";
const api = ({dispatch}) => (next) => (action) => {
    if (action.type !== 'api/apiCall') {
        next(action)
        return
    }
    next(action)
    console.log('keldi')
    const {url, method, type,data} = action.payload
    console.log({url,method,type})

    axios({
        baseURL : 'https://jsonplaceholder.typicode.com',
        url,
        method,
        data
    }).then(res => {
        dispatch({
            type,
            payload: res.data
        })
    })
}
export default api